package com.example.BackMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
