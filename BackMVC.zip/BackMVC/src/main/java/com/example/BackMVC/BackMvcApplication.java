package com.example.BackMVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackMvcApplication.class, args);
	}

}
