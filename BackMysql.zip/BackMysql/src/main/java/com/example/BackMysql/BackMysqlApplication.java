package com.example.BackMysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackMysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackMysqlApplication.class, args);
	}

}
